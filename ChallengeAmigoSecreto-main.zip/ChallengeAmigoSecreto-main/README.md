# ChallengeAmigoSecreto

<h1>Challenge del amigo secreto</h1>

En este proyecto ponemos en practica lo aprendido en HTML y JavaScript, probando funcionalidades como array, for, if, function, y otros; esto con el fin de
crear una dinamica en donde se pueda agregar el nombre de diferentes personas y luego con azar seleccionar a una de ellas.

Para correr este programa abrir el archivo .html en el navegador.
